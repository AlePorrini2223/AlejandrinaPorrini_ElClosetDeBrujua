'use strict';
const { randomNumber } = require('../../utils');
const productsJson = require('../../data/products.json');
const products = productsJson.map(({nameProduct, description, detailedDescription, condition, stuff, size, price}) => {
  return {
    nameProduct,
    description,
    detailedDescription,
    condition,
    stuff,
    categoryId: randomNumber(7),
    size,
    price,
    createAt : new Date,
    updateAt : new Date,
  }
})

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {

    await queryInterface.bulkInsert("Products", products,
      {}
    );
  },

  async down (queryInterface, Sequelize) {

    await queryInterface.bulkDelete('Products', null, {});
  }
};

